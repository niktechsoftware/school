<!-- start: PAGE CONTENT -->
						<div class="row">
							<div class="col-sm-12">
								<!-- start: INLINE TABS PANEL -->
								<div class="panel panel-white">
									<div class="panel-heading panel-orange">
									<p class="panel-title">Welcome to Student Panel</p>
										<div class="panel-tools">
											<div class="dropdown">
											<a data-toggle="dropdown" class="btn btn-xs dropdown-toggle btn-transparent-grey">
												<i class="fa fa-cog"></i>
											</a>
											<ul class="dropdown-menu dropdown-light pull-right" role="menu">
												<li>
													<a class="panel-collapse collapses" href="#"><i class="fa fa-angle-up"></i> <span>Collapse</span> </a>
												</li>
												<li>
													<a class="panel-refresh" href="#"> <i class="fa fa-refresh"></i> <span>Refresh</span> </a>
												</li>
												<li>
													<a class="panel-expand" href="#"> <i class="fa fa-expand"></i> <span>Fullscreen</span></a>
												</li>
											</ul>
											</div>
										</div>
									</div>
									<div class="panel-body">
										<div>  
										
										 <!-- <p class="alert alert-info"> Note : This is the area you can Select Fields send message Option. If you want to Send Please click given buttons. <br> -->
										</div>
										<div class="col-sm-4"><a href="<?php echo base_url(); ?>index.php/login/student_wise_icard">
											<button class=" btn panel-yellow btn-icon btn-block space10">
												<font size="5">Student Wise Icard  </font><span class="badge badge-info partition-pink"> 1 </span>
											</button>
											</a>
										</div>

										<div class="col-sm-4"><a href="<?php echo base_url(); ?>index.php/login/class_wise_icard">
											<button class=" btn panel-green btn-icon btn-block space10">
												<font size="5">Class Wise Icard  </font><span class="badge badge-info partition-pink"> 2 </span>
											</button>
											</a>
										</div>

										<div class="col-sm-4"><a href="<?php echo base_url(); ?>index.php/login/classteacher">
												<button class=" btn panel-red btn-icon btn-block space10">

													<font size="5">Class wise List  </font><span class="badge badge-info partition-pink"> 3 </span>
												</button>
												</a>
											</div>
											<br></br>
											<br></br>
										<div class="col-sm-4"><a href="<?php echo base_url(); ?>index.php/feepanel/classwisefeepanel">
												<button class="btn panel-red btn-icon btn-block space10">
													<font size="5">Class wise Due Fee</font><span class="badge badge-info partition-orenge"> 4 </span>
												</button>
												</a>
											</div>
										<div class="col-sm-4"><a href="<?php echo base_url(); ?>index.php/studentController/transportList">
												<button class="btn panel-azure btn-icon btn-block space10">

												<font size="5">	Transport Wise List</font><span class="badge badge-info partition-purple"> 5 </span>
												</button>
												</a>
											</div>
											
												<div class="col-sm-4"><a href="<?php echo base_url();?>index.php/studentController/drivertransportList">
												<button class="btn panel-yellow btn-icon btn-block space10">

												<font size="5">Driver Wise Transport List</font><span class="badge badge-info partition-black"> 6 </span>
												</button>
												</a>
											</div>
											<br></br>
											<br></br>
												<div class="col-sm-4"><a href="<?php echo base_url();?>index.php/studentController/yearwiseList">
												<button class="btn panel-green btn-icon btn-block space10">

												<font size="5">Year Wise Student List</font><span class="badge badge-info partition-black"> 7 </span>
												</button>
												</a>
											</div>
										<!--<div class="col-sm-4"><a href="<?php echo base_url();?>index.php/login/examDetail">-->
										<!--		<button class="btn btn-light-red btn-block btn-icon btn-block space10">-->

										<!--		<font size="5">	Marks Slip & List </font><span class="badge badge-info partition-black"> 4 </span>-->
										<!--		</button>-->
										<!--		</a>-->
										<!--	</div>-->
										<!--<div class="col-sm-4"><a href="<?php echo base_url(); ?>index.php/studentController/homeWorkReport">-->
										<!--		<button class="btn btn-light-yellow btn-icon btn-block space10">-->

										<!--			<font size="5"> Homework Report  </font><span class="badge badge-info partition-blue"> 5 </span>-->
										<!--		</button>-->
										<!--		</a>-->
										<!--	</div>-->
										<!--<div class="col-sm-4"><a href="<?php echo base_url(); ?>index.php/login/studentAttendance">-->
										<!--		<button class="btn btn-light-grey btn-icon btn-block space10">-->


										<!--			<font size="5"> Student Attendance </font><span class="badge badge-info partition-red"> 6 </span>-->

										<!--		</button>-->
										<!--		</a>-->
										<!--	</div>-->

									
								</div>
								</div>

          
              </div>
            
            
         
          </div>
        </div>
        </div>
