<article class="content col-sm-12 col-md-9">
      <h5>Refund and Cancellation Policy</h5>

      <p>Our focus is complete customer satisfaction. In the event, if you are displeased with the services provided, we will refund back the money, provided the reasons are genuine and proved after investigation. Please read the fine prints of each deal before buying it, it provides all the details about the services or the product you purchase.</p>
<p>In case of dissatisfaction from our services, clients have the liberty to cancel their projects and request a refund from us. Our Policy for the cancellation and refund will be as follows:</p>
 <p><strong>Cancellation Policy</strong></p>

<p>For Cancellations please contact the us via contact us link.</p> 

<p>Requests received later than <b>10-12</b> business days prior to the end of the current service period will be treated as cancellation of services for the next service period.</p>

<p><strong>Refund Policy</strong></p>

<p>We will try our best to create the suitable design concepts for our clients.</p>

<p>In case any client is not completely satisfied with our products we can provide a refund.</p> 

<p>If paid by credit card, refunds will be issued to the original credit card provided at the time of purchase and in case of payment gateway name payments refund will be made to the same account.</p>

<p><strong>Contact Information</strong></p>
<p>NIktech Software Solutions. welcomes your comments regarding this Terms of Use, please contact us by e-mail, or postal mail.</p>
<dl>
<dt>&nbsp;</dt>
<dd>Niktech Software Solutions.</dd>
<dt>&nbsp;</dt>
<dd>116/832 Rawatpur, Near City Model School Kakadeo, Kanpur-208019</dd>
<dt>&nbsp;</dt>
<dd>Rawatpur Gaon</dd>
<dt>&nbsp;</dt>
<dd>Kanpur -208019</dd>
</dl>
		
	  </article>