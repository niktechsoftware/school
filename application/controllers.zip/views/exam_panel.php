<div class="row">
							<div class="col-sm-12">
								<!-- start: INLINE TABS PANEL -->
								<div class="panel panel-white">
									<div class="panel-heading">
										<div class="panel-tools">
											<div class="dropdown">
											<a data-toggle="dropdown" class="btn btn-xs dropdown-toggle btn-transparent-grey">
												<i class="fa fa-cog"></i>
											</a>
											<ul class="dropdown-menu dropdown-light pull-right" role="menu">
												<li>
													<a class="panel-collapse collapses" href="#"><i class="fa fa-angle-up"></i> <span>Collapse</span> </a>
												</li>
												<li>
													<a class="panel-refresh" href="#"> <i class="fa fa-refresh"></i> <span>Refresh</span> </a>
												</li>
												<li>
													<a class="panel-expand" href="#"> <i class="fa fa-expand"></i> <span>Fullscreen</span></a>
												</li>
											</ul>
											</div>
										</div>
									</div>
									<div class="panel-body">
										<div>  <p class="alert alert-danger">Welcome to Exam Panel...</p>
										 <p class="alert alert-info"> Note : This is the area you can Find Your Exam Detail . If you want to find Detail Please click given buttons. <br>
										</p></div>
										<div class="col-sm-4"><a href="http://localhost/school/index.php/exampanel/studentwiseExampanel">
												<button class="btn btn btn-green btn-icon btn-block space10">

													<font size="5">Student wise</font><span class="badge badge-info partition-pink"> 1 </span>
												</button>
												</a>
											</div>
										<div class="col-sm-4"><a href="http://localhost/school/index.php/exampanel/classwiseExampanel">
												<button class="btn btn-blue btn-icon btn-block space10">
													<font size="5">Class wise</font><span class="badge badge-info partition-orenge"> 2 </span>
												</button>
												</a>
											</div>
										<div class="col-sm-4"><a href="http://localhost/school/index.php/exampanel/gradcardExampanel">
												<button class="btn  btn-light-purple btn-icon btn-block space10">

												<font size="5">	Grad Card</font><span class="badge badge-info partition-purple"> 3 </span>
												</button>
												</a>
											</div>

										<div class="col-sm-4"><a href="http://localhost/school/index.php/exampanel/topperfomertotalExampanel">
												<button class="btn btn-light-red btn-block btn-icon btn-block space10">

												<font size="5">	Top 10 performer <br> Total</font><span class="badge badge-info partition-black"> 4 </span>
												</button>
												</a>
											</div>
										<div class="col-sm-4"><a href="http://localhost/school/index.php/exampanel/topperfomersubjectExampanel">
												<button class="btn btn-light-yellow btn-icon btn-block space10">

													<font size="5">Top 10 performer<br>By Subject</font><span class="badge badge-info partition-blue"> 5 </span>
												</button>
												</a>
											</div>
										<div class="col-sm-4"><a href="http://localhost/school/index.php/exampanel/admitcardstudentExampanel">
												<button class="btn btn-light-grey btn-icon btn-block space10">

													<font size="5">Admit Card <br>Student Wise</font><span class="badge badge-info partition-red"> 6 </span>
												</button>
												</a>
											</div>


                      <div class="col-sm-4"><a href="http://localhost/school/index.php/exampanel/admitcardclassExampanel">
												<button class="btn btn-light-red btn-block btn-icon btn-block space10">

												<font size="5">	Admit Card <br> Class Wise</font><span class="badge badge-info partition-black"> 4 </span>
												</button>
												</a>
											</div>
										<div class="col-sm-4"><a href="http://localhost/school/index.php/exampanel/performancechartExampanel">
												<button class="btn btn-light-yellow btn-icon btn-block space10">

													<font size="5">Download performance<br> Chart</font><span class="badge badge-info partition-blue"> 5 </span>
												</button>
												</a>
											</div>
										<div class="col-sm-4"><a href="http://localhost/school/index.php/exampanel/smsExampanel">
												<button class="btn btn-light-grey btn-icon btn-block space10">

													<font size="5">Send SMS <br> For Examination </font><span class="badge badge-info partition-red"> 6 </span>
												</button>
												</a>
											</div>


								</div>
								<!-- end: INLINE TABS PANEL -->
							</div>
						</div>
						<!-- end: PAGE CONTENT-->
</div>