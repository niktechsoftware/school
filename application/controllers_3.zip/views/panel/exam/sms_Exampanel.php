<form action="<?php echo base_url()?>index.php/exampanel/sendsms_exam" method="post">
    
    <textarea rows="5" cols="7" class="form-control" id="msg" name="msg" placeholder="Send Message to All Student For Examination"></textarea><br>
<input type="submit" name="send" value="Send Message" style="background-color:orange;height:35px; bg-color:blue; border:2px solid;">
</form>