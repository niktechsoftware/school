<div class="row">
							<div class="col-sm-12">
								<!-- start: INLINE TABS PANEL -->
								<div class="panel panel-white">
									<div class="panel-heading">
										<div class="panel-tools">
											<div class="dropdown">
											<a data-toggle="dropdown" class="btn panel-xs dropdown-toggle btn-transparent-grey">
												<i class="fa fa-cog"></i>
											</a>
											<ul class="dropdown-menu dropdown-light pull-right" role="menu">
												<li>
													<a class="panel-collapse collapses" href="#"><i class="fa fa-angle-up"></i> <span>Collapse</span> </a>
												</li>
												<li>
													<a class="panel-refresh" href="#"> <i class="fa fa-refresh"></i> <span>Refresh</span> </a>
												</li>
												<li>
													<a class="panel-expand" href="#"> <i class="fa fa-expand"></i> <span>Fullscreen</span></a>
												</li>
											</ul>
											</div>
										</div>
									</div>
									<div class="panel-body">
										<div>  <p class="alert alert-danger">Welcome to Time Table Panel...</p>
										 <p class="alert alert-info"> Note : This is the area you can Select Fields send message Option. If you want to Send Please click given buttons. <br>
										</p></div>

										<div class="col-sm-4"><a href="<?php echo base_url(); ?>index.php/vreportpanel/tcvreportpanel">
												<button class="btn panel-green btn-icon btn-block space10">

													<font size="5">TC Varification</font><span class="badge badge-info partition-pink"> 1 </span>
												</button>
												</a>
											</div>
										<div class="col-sm-4"><a href="<?php echo base_url(); ?>index.php/vreportpanel/ccvreportpanel">
												<button class="btn panel-blue btn-icon btn-block space10">
													<font size="5">CC Varification</font><span class="badge badge-info partition-orenge"> 2 </span>
												</button>
												</a>
											</div>
										<div class="col-sm-4"><a href="<?php echo base_url(); ?>index.php/login/tc">
												<button class="btn panel-purple btn-icon btn-block space10">

												<font size="5">TC  Generate</font><span class="badge badge-info partition-purple"> 3 </span>
												</button>
												</a>
											</div>

										<div class="col-sm-4"><a href="<?php echo base_url(); ?>index.php/vreportpanel/ccgenvreportpanel">
												<button class="btn panel-red btn-icon btn-block space10">

												<font size="5">CC Generate   </font><span class="badge badge-info partition-black"> 4 </span>
												</button>
												</a>
											</div>
										<div class="col-sm-4"><a href="<?php echo base_url(); ?>index.php/vreportpanel/prostuvreportpanel">
												<button class="btn panel-azure btn-icon btn-block space10">

													<font size="5">Promotion List <br>Of Student </font><span class="badge badge-info partition-blue"> 5 </span>
												</button>
												</a>
											</div>

										<div class="col-sm-4"><a href="<?php echo base_url(); ?>index.php/vreportpanel/jumpstuvreportpanel">
												<button class="btn panel-orange btn-icon btn-block space10">

													<font size="5">Student Jump to <br> another Class </font><span class="badge badge-info partition-red"> 6 </span>
												</button>
												</a>
											</div>

										<div class="col-sm-4"><a href="<?php echo base_url(); ?>index.php/vreportpanel/birthrepovreportpanel">
												<button class="btn panel-orange btn-icon btn-block space10">

													<font size="5">Report By <br> Birth Date </font><span class="badge badge-info partition-red"> 6 </span>
												</button>
												</a>
											</div>


                      <div class="col-sm-4"><a href="<?php echo base_url(); ?>index.php/vreportpanel/stuvarivreportpanel">
												<button class="btn panel-pink btn-icon btn-block space10">

 												<font size="5">	Student Varification<span class="badge badge-info partition-black"> 4 </span>
												</button>
												</a>
											</div>

										<div class="col-sm-4"><a href="<?php echo base_url(); ?>index.php/vreportpanel/teachvarivreportpanel">
												<button class="btn panel-pink btn-icon btn-block space10">

													<font size="5">Teacher Varification</font><span class="badge badge-info partition-red"> 6 </span>
												</button>
												</a>
											</div>


								</div>
								<!-- end: INLINE TABS PANEL -->
							</div>
						</div>
						<!-- end: PAGE CONTENT-->
</div>