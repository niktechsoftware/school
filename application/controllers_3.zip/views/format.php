<html>
<head>

<style>
table , tr, th{

  border :1px solid black;
  border-collapse:collapse;
}
</style>
</head>
<body>
<div style="width:80%; margin-left:auto; margin-right:auto; border:1px  solid blue; background-color:#e30e0e;">

<div style="width:95%; margin-left:auto; margin-right:auto; border:1px  solid yellow; height:90px;">
Here logo and Name
</div>
<br>
<div>
<table style="width:95%; margin-left:auto; margin-right:auto; border:1px solid black; background-color:white;">
<tr>
<th colspan="4" rowspan="2" >SCHOLASTIC AREA </th>
<th colspan="5" rowspan="2">Term 1 (100 Marks) </th>
<th colspan="5" rowspan="2">Term 2 (100 Marks) </th>
<th colspan="3">OVERALL</th>

</tr>

<tr>
<th colspan="3">Term 2 (50)+ Term 2(50)</th>
</tr>

<tr>

<th colspan="4" rowspan="2">Subjects</th>

<th>Per. <br> Test</th>
<th>Note <br> Book</th>
<th>SEA</th>
<th>Half <br> Yearly</th>
<th>Total</th>

<th>Per. <br> Test</th>
<th>Note <br> Book</th>
<th>SEA</th>
<th>Yearly <br> Exam</th>
<th>Total</th>

<th>Grand<br> Toltal</th>
<th rowspan="2">Grade</th>
<th rowspan="2">Rank</th>
</tr>


<!-- Dynamic -->
<tr>
<th>10</th>
<th>5</th>
<th>5</th>
<th>80</th>
<th>100</th>

<th>10</th>
<th>5</th>
<th>5</th>
<th>80</th>
<th>100</th>

<th>100</th>
</tr>

<!--Dynamic Subject-->
<tr>
<td colspan="4">English</td>

<td>0</td>
<td>0</td>
<td>0</td>
<td>0</td>
<td>0</td>

<td>0</td>
<td>0</td>
<td>0</td>
<td>0</td>
<td>0</td>

<td>0</td>
<td>0</td>
<td>0</td>

</tr>

</table>
</div>

<br>
<div>
<table style="width:95%; margin-left:auto; margin-right:auto; border:1px solid black; background-color:white;">

<tr>
<td colspan="2"> CO - SCHOLASTIC Area  </td>
<td colspan="2">CO - SCHOLASTIC Area</td>
</tr>

<tr>
<td>Work Education</td>
<td>0</td>
<td>Work Education</td>
<td>0</td>
</tr>

<tr>
<td>Art Education</td>
<td>0</td>
<td>Art Education</td>
<td>0</td>
</tr>

<tr>
<td>Helth</td>
<td>0</td>
<td>Helth</td>
<td>0</td>
</tr>
</table>
</div>

<br>
<div>
<table style="width:95%; margin-left:auto; margin-right:auto; border:1px solid black; background-color:white;">

<tr>
<td colspan="2"> Grade  </td>
<td colspan="2">Grade</td>
</tr>

<tr>
<td>Work Education</td>
<td>0</td>
<td>Work Education</td>
<td>0</td>
</tr>

</table>
</div>

<br>
<div>
<table style="width:95%; margin-left:auto; margin-right:auto; border:1px solid black; background-color:white;">

<tr>
<td>
0
</td>
<td>
0
</td>
<td>
0
</td>
<td>
0
</td>
</tr>
</table>
</div>

<br>

<div style=" width:95%; margin-left:auto; margin-right:auto;">
<div style="width:50%; float:left;">

<table style="width:90%; border:1px solid black; background-color:white;">
<tr>
<th colspan="3">Co- SCHOLASTIC Area</th>
</tr>

<tr>
<th> Activity </th>
<th>T1</th>
<th>T2</th>
</tr>

<!-- Dynamic -->
<tr>
<td>Hello</td>
<td>Hello</td>
<td>Hello</td>

</tr>
</table>
<table style="width:70%; border:1px solid black; background-color:white;">
<tr>
<td>Hello</td>
</tr>
</table>


</div>



<div style="width:50%; float:right;">

<table style="width:90%; border:1px solid black; background-color:white;">

<tr>
<th colspan="3"> Discipline</th>
</tr>
<tr>
<th> Activity </th>
<th>T1</th>
<th>T2</th>
</tr>

<!-- Dynamic -->
<tr>
<td>Hello</td>
<td>Hello</td>
<td>Hello</td>

</tr>
</table>

<table style="width:70%; border:1px solid black; background-color:white;">
<tr>
<td>Hello</td>
</tr>
</table>

</div>

</div>

<br/>
<div>
<table style="width:95%;  margin-left:auto; margin-right:auto; border:1px solid black; background-color:white;">
<tr>
<th>
MARKS RANGE
</th>
<th>
GRADE
</th>
</tr>


<!-- Dynamic -->
<tr>
<td>Heelo</td>
<td>Heelo</td>

</tr>

</table>


</div>






</div>

</body>
</body>
</html>