<?php
echo "cceMarksDetail";